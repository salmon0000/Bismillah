
alert("assalamualaikum warahmatullahi wabarakatuh")
alert("Hi Tariska Aaliyah Tsabitah 👋🏻");
alert("Selamat ulang taun tayisss");
alert("yang keberapa yaa?? wkwkwkwk");
alert("intinya udah kepala dua ajaa");
alert("moga diberi keberkah an umurnya, diberi kelancaran rezeki dan karir nya");
alert("makin sayang juga ke orang tua dan dikelilingin orang-orang baik")
alert("makin kuat buat ngadepin segala problem di dunia ini💪🏻");
alert("hebat sih udah ngelaluin sampe sejauh ini✨");
alert("dijaga semangat sama kesehatannya yaa💪🏻");
alert("apalagi yaa... yaa makin positive vibes aja deh kedepanya wkwkwk");
alert("maaf yaa baru ngucapin soalnya plannya antara paling pertama kl ga paling terakhir");
alert("tapi karna salah perkiraan tanggal ultah meleset jadi nya paling terakhir aja")
alert("udah jadi orang yg ngucapin terakhir belom buat hari ini??");
alert("kalo udah alhamdulillah, kl belom yaudah gapapa 😂");
alert("yaudah kl gitu terimakasih sudah melihat ini, wabillahi taufiq wal hidayah wassalamualaikum warahmatullahi wabarakatuh🙏🏻");
